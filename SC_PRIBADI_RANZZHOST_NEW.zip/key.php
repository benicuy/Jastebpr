<?php
session_start();
$admin_key = "ALN"; // ganti sesuka lu

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $key = $_POST['key'];
    if ($key === $admin_key) {
        $_SESSION['admin'] = true;
        header("Location: admin.php");
        exit;
    } else {
        $error = "Key tidak valid. Akses ditolak.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Access — ALN JASTEB</title>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --accent: #4e73df;
            --accent2: #a855f7;
            --bg: #04040a;
            --border: rgba(78,115,223,.2);
            --text: #e2e8f0;
            --muted: #4a5568;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            background: var(--bg);
            font-family: 'Space Grotesk', sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            color: var(--text);
        }

        /* Noise overlay */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E");
            pointer-events: none;
            z-index: 0;
        }

        /* Grid */
        .grid-bg {
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(rgba(78,115,223,.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(78,115,223,.04) 1px, transparent 1px);
            background-size: 48px 48px;
            pointer-events: none;
            z-index: 0;
        }

        /* Orbs */
        .orb {
            position: fixed;
            border-radius: 50%;
            filter: blur(90px);
            pointer-events: none;
            z-index: 0;
        }
        .orb-1 { width: 450px; height: 450px; background: rgba(78,115,223,.07); top: -120px; right: -100px; }
        .orb-2 { width: 350px; height: 350px; background: rgba(168,85,247,.05); bottom: -80px; left: -80px; }
        .orb-3 {
            width: 180px; height: 180px;
            background: rgba(78,115,223,.1);
            top: 50%; left: 50%;
            transform: translate(-50%,-50%);
            animation: breathe 5s ease-in-out infinite;
        }

        @keyframes breathe {
            0%, 100% { opacity: .5; transform: translate(-50%,-50%) scale(1); }
            50% { opacity: 1; transform: translate(-50%,-50%) scale(1.4); }
        }

        /* Card */
        .card {
            position: relative;
            z-index: 1;
            width: 420px;
            background: rgba(8, 8, 20, 0.9);
            border: 1px solid var(--border);
            border-radius: 28px;
            padding: 48px 40px;
            backdrop-filter: blur(30px);
            animation: slideUp .6s cubic-bezier(.16,1,.3,1) forwards;
            opacity: 0;
            transform: translateY(20px);
        }

        @keyframes slideUp {
            to { opacity: 1; transform: translateY(0); }
        }

        /* Glowing top bar */
        .card-topbar {
            position: absolute;
            top: 0; left: 50%;
            transform: translateX(-50%);
            width: 60%;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(78,115,223,.8), rgba(168,85,247,.6), transparent);
        }

        /* Header */
        .header {
            text-align: center;
            margin-bottom: 36px;
        }

        .icon-wrap {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 72px;
            height: 72px;
            background: linear-gradient(135deg, rgba(78,115,223,.12), rgba(168,85,247,.08));
            border: 1px solid rgba(78,115,223,.3);
            border-radius: 22px;
            margin-bottom: 20px;
            position: relative;
        }

        .icon-wrap::after {
            content: '';
            position: absolute;
            inset: -1px;
            border-radius: 22px;
            background: linear-gradient(135deg, var(--accent), var(--accent2));
            opacity: 0;
            z-index: -1;
            filter: blur(10px);
            transition: opacity .4s;
        }
        .icon-wrap:hover::after { opacity: .5; }

        .icon-wrap i {
            font-size: 30px;
            background: linear-gradient(135deg, #4e73df, #a855f7);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .restricted-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: rgba(168,85,247,.1);
            border: 1px solid rgba(168,85,247,.25);
            border-radius: 100px;
            padding: 4px 12px;
            font-size: 9px;
            font-family: 'JetBrains Mono', monospace;
            letter-spacing: 2px;
            color: #a855f7;
            text-transform: uppercase;
            margin-bottom: 14px;
        }

        .restricted-badge i { font-size: 8px; }

        h1 {
            font-size: 24px;
            font-weight: 700;
            letter-spacing: -0.8px;
            color: #fff;
            margin-bottom: 6px;
        }

        h1 span {
            background: linear-gradient(90deg, #4e73df, #a855f7);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .subtitle {
            font-size: 12px;
            color: var(--muted);
        }

        /* Divider */
        .divider {
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(78,115,223,.15), transparent);
            margin: 28px 0;
        }

        /* Input */
        .field-label {
            font-size: 11px;
            font-family: 'JetBrains Mono', monospace;
            letter-spacing: 1.5px;
            color: var(--muted);
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        .input-wrap {
            position: relative;
            margin-bottom: 16px;
        }

        .input-wrap .ico {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--muted);
            font-size: 14px;
            transition: color .3s;
            pointer-events: none;
        }

        input[type="text"] {
            width: 100%;
            padding: 15px 50px 15px 46px;
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.07);
            border-radius: 14px;
            color: #fff;
            font-size: 14px;
            font-family: 'JetBrains Mono', monospace;
            letter-spacing: 2px;
            transition: all .3s;
            outline: none;
        }

        input[type="text"]:focus {
            border-color: rgba(78,115,223,.5);
            background: rgba(78,115,223,.04);
            box-shadow: 0 0 0 3px rgba(78,115,223,.08);
        }

        .input-wrap:focus-within .ico { color: var(--accent); }
        input::placeholder { color: rgba(255,255,255,.15); letter-spacing: 0; font-size: 13px; }

        /* Show/hide password toggle */
        .toggle-vis {
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--muted);
            cursor: pointer;
            font-size: 14px;
            transition: color .3s;
            background: none;
            border: none;
            padding: 4px;
        }
        .toggle-vis:hover { color: var(--accent); }

        /* Button */
        .btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #4e73df, #7c3aed);
            border: none;
            border-radius: 14px;
            color: #fff;
            font-size: 14px;
            font-weight: 600;
            font-family: 'Space Grotesk', sans-serif;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition: all .3s;
            letter-spacing: .3px;
        }

        .btn::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(255,255,255,.12), transparent);
        }

        .btn:hover { transform: translateY(-1px); box-shadow: 0 8px 24px rgba(78,115,223,.35); }
        .btn:active { transform: translateY(0); }
        .btn i { margin-right: 8px; }

        /* Error */
        .error-box {
            display: flex;
            align-items: center;
            gap: 10px;
            background: rgba(220,38,38,.08);
            border: 1px solid rgba(220,38,38,.2);
            border-radius: 12px;
            padding: 12px 16px;
            margin-top: 14px;
            animation: shake .4s ease;
        }

        @keyframes shake {
            0%,100%{transform:translateX(0)}
            20%{transform:translateX(-5px)}
            40%{transform:translateX(5px)}
            60%{transform:translateX(-3px)}
            80%{transform:translateX(3px)}
        }

        .error-box i { color: #ef4444; font-size: 14px; flex-shrink: 0; }
        .error-box span { font-size: 12px; color: #ef4444; }

        /* Bottom menu */
        .bottom-links {
            display: flex;
            gap: 10px;
            margin-top: 24px;
            padding-top: 20px;
            border-top: 1px solid rgba(255,255,255,.04);
        }

        .link-btn {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 11px;
            background: rgba(255,255,255,.02);
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 12px;
            color: var(--muted);
            font-size: 12px;
            font-family: 'Space Grotesk', sans-serif;
            cursor: pointer;
            text-decoration: none;
            transition: all .3s;
        }

        .link-btn:hover {
            background: rgba(78,115,223,.08);
            border-color: rgba(78,115,223,.2);
            color: var(--accent);
        }

        .link-btn i { font-size: 13px; }

        /* Footer */
        .footer-text {
            text-align: center;
            margin-top: 20px;
            font-size: 10px;
            color: rgba(255,255,255,.12);
            font-family: 'JetBrains Mono', monospace;
            letter-spacing: 1px;
        }

        @media (max-width: 460px) {
            .card { width: 92%; padding: 36px 24px; }
            h1 { font-size: 20px; }
        }
    </style>
</head>
<body>

<div class="grid-bg"></div>
<div class="orb orb-1"></div>
<div class="orb orb-2"></div>
<div class="orb orb-3"></div>

<div class="card">
    <div class="card-topbar"></div>

    <div class="header">
        <div class="restricted-badge">
            <i class="fas fa-lock"></i>
            Restricted Area
        </div>
        <div class="icon-wrap">
            <i class="fas fa-user-shield"></i>
        </div>
        <h1>Admin <span>Access</span></h1>
        <p class="subtitle">Khusus admin — ALN Jasteb</p>
    </div>

    <div class="divider"></div>

    <form method="POST">
        <div class="field-label">Admin Key</div>
        <div class="input-wrap">
            <i class="fas fa-key ico"></i>
            <input type="password" id="keyInput" name="key" placeholder="Masukkan admin key" required autocomplete="off">
            <button type="button" class="toggle-vis" onclick="toggleKey()" id="toggleBtn">
                <i class="fas fa-eye" id="eyeIcon"></i>
            </button>
        </div>
        <button type="submit" class="btn">
            <i class="fas fa-right-to-bracket"></i>
            Verifikasi & Masuk
        </button>
    </form>

    <?php if(isset($error)): ?>
    <div class="error-box">
        <i class="fas fa-circle-xmark"></i>
        <span><?= htmlspecialchars($error) ?></span>
    </div>
    <?php endif; ?>

    <div class="bottom-links">
        <a class="link-btn" href="javascript:void(0)" onclick="contactCS()">
            <i class="fas fa-headset"></i>
            Hubungi CS
        </a>
        <a class="link-btn" href="javascript:void(0)" onclick="contactGrub()">
            <i class="fab fa-whatsapp"></i>
            Grup Admin
        </a>
    </div>
</div>

<div class="footer-text">ALN JASTEB · ADMIN PANEL · SECURE ACCESS</div>

<script>
function toggleKey() {
    const input = document.getElementById('keyInput');
    const icon = document.getElementById('eyeIcon');
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

function contactCS() {
    const pesan = "Halo Admin Aln, saya ingin bertanya tentang panel admin";
    window.open(`https://wa.me/6285353389626?text=${encodeURIComponent(pesan)}`, '_blank');
}

function contactGrub() {
    window.open("https://chat.whatsapp.com/EaFyeDRqODhIfMytYX284a", '_blank');
}
</script>
</body>
</html>

<?php 
$nik = "𝙒𝙀𝘽 | 𝙍𝘼𝙉𝙕𝙕 𝙃𝙊𝙎𝙏 ||";
$sender = "admin@ranzz.id";
?>
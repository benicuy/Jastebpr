<?php
session_start();

// CEK MAINTENANCE PALING ATAS - SEBELUM APA PUN
$maintenance = file_exists('maintenance.json') ? json_decode(file_get_contents('maintenance.json'), true) : ['status' => false, 'message' => 'Sedang maintenance, coba lagi nanti!'];
if($maintenance['status']) {
    die('
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Maintenance - aln</title>
        <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
        <style>
            * { margin:0; padding:0; box-sizing:border-box; }
            body {
                background: #03050a;
                font-family: "Orbitron", monospace;
                min-height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            .maintenance-box {
                text-align: center;
                background: rgba(0,0,0,0.7);
                padding: 50px;
                border-radius: 30px;
                border: 2px solid #f6c23e;
                max-width: 500px;
                margin: 20px;
            }
            .maintenance-box i {
                font-size: 80px;
                color: #f6c23e;
                margin-bottom: 20px;
            }
            .maintenance-box h1 {
                color: #f6c23e;
                margin-bottom: 15px;
            }
            .maintenance-box p {
                color: #aaa;
                margin-bottom: 20px;
            }
            .maintenance-box .message {
                background: rgba(246,194,62,0.1);
                padding: 15px;
                border-radius: 15px;
                color: #f6c23e;
            }
        </style>
    </head>
    <body>
        <div class="maintenance-box">
            <i class="fas fa-tools"></i>
            <h1>🔧 MAINTENANCE MODE</h1>
            <p>Sistem sedang dalam perbaikan</p>
            <div class="message">📢 ' . htmlspecialchars($maintenance['message']) . '</div>
        </div>
    </body>
    </html>
    ');
    exit;
}

// CEK SESSION BUYER
if(!isset($_SESSION['buyer'])) {
    header("Location: buyer_login.php");
    exit;
}

$keysFile = 'data_keys.json';
$keys = file_exists($keysFile) ? json_decode(file_get_contents($keysFile), true) : [];
$buyer_key = $_SESSION['buyer_key'];
$buyerInfo = null;
foreach($keys as $k) {
    if($k['key'] === $buyer_key) {
        $buyerInfo = $k;
        break;
    }
}

if(strtotime($buyerInfo['expired']) < time()) {
    session_destroy();
    header("Location: buyer_login.php?msg=expired");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CREATE PANEL PREMIUM ALN HOST ></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&family=Orbitron:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.css">
    
    <style>
        :root {
            /* Warna Biru Muda & Putih Terang */
            --primary: #00d2ff; 
            --accent: #ffffff;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(rgba(10, 25, 47, 0.7), rgba(0, 0, 0, 0.9)), url('https://i.ibb.co.com/NdPjZT65/IMG-20260524-WA0160.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #fff;
            overflow: hidden;
        }

        .navbar-custom {
            position: fixed;
            top: 0;
            width: 100%;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(15px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            padding: 15px 20px;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar-brand {
            font-family: 'Orbitron', sans-serif;
            font-size: 20px;
            font-weight: 700;
            color: #fff !important;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        
        /* Ganti hijau ke biru muda */
        .navbar-brand span { color: var(--primary); text-shadow: 0 0 10px var(--primary); }

        .user-info { font-size: 14px; color: var(--primary); font-weight: 600; }

        .glass-card {
            width: 90%;
            max-width: 450px;
            padding: 40px;
            background: rgba(255, 255, 255, 0.07);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.6);
            text-align: center;
        }

        .card-title {
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 30px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--accent);
            text-shadow: 0 0 5px rgba(255,255,255,0.3);
        }

        .form-control {
            background-color: rgba(255, 255, 255, 0.05);
            color: #fff;
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 30px;
            padding: 25px 20px;
            text-align: center;
        }

        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.1);
            border-color: var(--primary);
            color: #fff;
            box-shadow: 0 0 15px rgba(0, 210, 255, 0.4);
        }

        .btn-custom {
           background: linear-gradient(45deg, var(--primary), var(--accent));
           border: none;
           color: #003366; /* Teks biru gelap agar kontras dengan tombol terang */
           font-weight: 700;
           width: 100%;
           padding: 12px;
           border-radius: 30px;
           text-transform: uppercase;
           transition: 0.3s;
           box-shadow: 0 4px 15px rgba(0, 210, 255, 0.4);
       }

        .btn-custom:hover { 
            transform: translateY(-3px); 
            box-shadow: 0 8px 25px rgba(255, 255, 255, 0.5); 
            filter: brightness(1.1);
        }

       .logout-link { margin-top: 20px; display: block; color: #ff7675; font-size: 13px; text-decoration: none; opacity: 0.8; }
       .logout-link:hover { opacity: 1; color: #ff4d4d; }
    </style>
</head>
<body>
    <!-- Musik otomatis -->
    <audio id="bg-music" autoplay loop>
        <source src="https://files.catbox.moe/f9ai20.mp3" type="audio/mpeg">
    </audio>
    
    <nav class="navbar-custom">
        <div class="navbar-brand">MARGA <span>ALN HOST</span></div>      
    </nav>

    <div class="glass-card">
        <div style="font-size: 40px; color: var(--primary); margin-bottom: 20px; filter: drop-shadow(0 0 10px var(--primary));">
            <i class="fas fa-rocket"></i>
        </div>
        <h2 class="card-title">Create Panel Jasteb</h2>
        
        <form method="post" action="panel.php">
            <div class="form-group">
                <input type="text" name="WEB" id="WEB" class="form-control" placeholder="Masukin Nama Panel..." required autocomplete="off">
            </div>
            <button type="submit" class="btn-custom">
                <i class="fas fa-plus-circle mr-2"></i> Buat Sekarang
            </button>
        </form>

        <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Keluar Sistem</a>
    </div>
   
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    
    <script>
       function showWelcomeNotification() {
            Swal.fire({
                title: 'Welcome Back!',
                text: 'Halo mau buat panel apa hari ini?',
                icon: 'info', // Mengubah icon ke info (biru)
                confirmButtonText: 'GASKEUN',
                background: '#0a192f',
                confirmButtonColor: '#00d2ff',
                customClass: { title: 'text-white', content: 'text-white' }
            });
        }

        document.addEventListener('DOMContentLoaded', function() {
            showWelcomeNotification();
        });
   </script>
</body>
</html>
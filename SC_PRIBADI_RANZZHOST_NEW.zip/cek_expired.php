<?php
// Cek expired buyer
$expired_file = __DIR__ . '/expired.txt';
if(file_exists($expired_file)) {
    $expired_date = file_get_contents($expired_file);
    if(strtotime($expired_date) < time()) {
        die("<h2 style='color:red;text-align:center;margin-top:50px;'>⚠️ PANEL SUDAH EXPIRED ⚠️<br><small>Hubungi admin untuk perpanjang</small></h2>");
    }
}
?>
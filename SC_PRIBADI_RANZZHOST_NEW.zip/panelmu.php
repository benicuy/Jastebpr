<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
<title>🥶ALN JASTEB GACOR🥶</title>

<!-- Fonts Premium -->
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>

<!-- Three.js untuk efek 3D -->
<script type="importmap">
    {
        "imports": {
            "three": "https://unpkg.com/three@0.128.0/build/three.module.js"
        }
    }
</script>

<!-- Anime.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js"></script>

<!-- GSAP untuk animasi profesional -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Poppins', sans-serif;
    min-height: 100vh;
    background: #050510;
    color: white;
    overflow-x: hidden;
    position: relative;
}

/* Canvas 3D Background */
#canvas-3d {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 0;
    opacity: 0.8;
}

/* HD Gradient Overlay */
.gradient-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle at 50% 50%, rgba(78, 115, 223, 0.15), rgba(0, 0, 0, 0.6));
    z-index: 1;
    pointer-events: none;
}

/* Floating Orbs HD */
.orb {
    position: fixed;
    border-radius: 50%;
    filter: blur(60px);
    z-index: 1;
    pointer-events: none;
    opacity: 0.4;
}

.orb-1 {
    width: 500px;
    height: 500px;
    top: -250px;
    right: -250px;
    background: radial-gradient(circle, #4e73df, #1cc88a);
    animation: floatOrb 15s ease-in-out infinite;
}

.orb-2 {
    width: 600px;
    height: 600px;
    bottom: -300px;
    left: -300px;
    background: radial-gradient(circle, #e74a3b, #f6c23e);
    animation: floatOrb 20s ease-in-out infinite reverse;
}

.orb-3 {
    width: 400px;
    height: 400px;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: radial-gradient(circle, rgba(78, 115, 223, 0.3), transparent);
    animation: pulseOrb 8s ease-in-out infinite;
}

@keyframes floatOrb {
    0%, 100% { transform: translate(0, 0) scale(1); }
    50% { transform: translate(-50px, 50px) scale(1.1); }
}

@keyframes pulseOrb {
    0%, 100% { opacity: 0.2; transform: translate(-50%, -50%) scale(1); }
    50% { opacity: 0.5; transform: translate(-50%, -50%) scale(1.2); }
}

/* Main Container 3D */
.container {
    position: relative;
    z-index: 10;
    background: rgba(8, 8, 20, 0.7);
    backdrop-filter: blur(25px);
    -webkit-backdrop-filter: blur(25px);
    border: 1px solid rgba(78, 115, 223, 0.3);
    border-radius: 60px;
    padding: 55px 45px;
    max-width: 650px;
    width: 100%;
    margin: 100px auto;
    box-shadow: 0 40px 80px -20px rgba(0, 0, 0, 0.6), 
                0 0 0 1px rgba(78, 115, 223, 0.2),
                inset 0 1px 0 rgba(255, 255, 255, 0.05);
    transform-style: preserve-3d;
    perspective: 1000px;
    animation: containerFloat 6s ease-in-out infinite;
}

@keyframes containerFloat {
    0%, 100% { transform: translateY(0px) rotateX(0deg); }
    50% { transform: translateY(-10px) rotateX(2deg); }
}

.container::before {
    content: '';
    position: absolute;
    top: -2px;
    left: -2px;
    right: -2px;
    bottom: -2px;
    background: linear-gradient(45deg, #4e73df, #1cc88a, #f6c23e, #e74a3b, #4e73df);
    background-size: 300% 300%;
    border-radius: 62px;
    opacity: 0;
    z-index: -1;
    transition: opacity 0.5s;
    animation: borderGlow 4s ease infinite;
}

@keyframes borderGlow {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

.container:hover::before {
    opacity: 0.4;
}

/* Header Icons 3D */
.header-icons {
    display: flex;
    justify-content: center;
    gap: 20px;
    margin-bottom: 35px;
}

.icon-circle {
    width: 75px;
    height: 75px;
    border-radius: 50%;
    background: linear-gradient(135deg, rgba(78, 115, 223, 0.25), rgba(28, 200, 138, 0.15));
    border: 1px solid rgba(255, 255, 255, 0.15);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 30px;
    color: #4e73df;
    transform-style: preserve-3d;
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    box-shadow: 0 10px 20px -5px rgba(0, 0, 0, 0.3);
}

.icon-circle:hover {
    transform: translateY(-10px) rotateY(180deg);
    border-color: #4e73df;
    box-shadow: 0 20px 40px -10px rgba(78, 115, 223, 0.5);
}

.icon-circle:nth-child(1) { transition-delay: 0s; }
.icon-circle:nth-child(2) { transition-delay: 0.1s; }
.icon-circle:nth-child(3) { transition-delay: 0.2s; }
.icon-circle:nth-child(4) { transition-delay: 0.3s; }

/* Title HD */
h2 {
    font-family: 'Orbitron', sans-serif;
    font-weight: 900;
    font-size: 3rem;
    margin-bottom: 15px;
    background: linear-gradient(135deg, #fff, #4e73df, #1cc88a, #f6c23e);
    background-size: 300% 300%;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    text-transform: uppercase;
    letter-spacing: 3px;
    animation: gradientShift 4s ease infinite;
}

@keyframes gradientShift {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

.glow-text {
    position: relative;
    display: inline-block;
}

.glow-text::after {
    content: '';
    position: absolute;
    top: -30px;
    left: -30px;
    right: -30px;
    bottom: -30px;
    background: radial-gradient(circle, rgba(78, 115, 223, 0.4), transparent 70%);
    filter: blur(30px);
    z-index: -1;
    animation: glowPulseHD 3s ease-in-out infinite;
}

@keyframes glowPulseHD {
    0%, 100% { opacity: 0.6; transform: scale(1); }
    50% { opacity: 1; transform: scale(1.05); }
}

.subtitle {
    font-size: 1.2rem;
    color: rgba(255, 255, 255, 0.7);
    margin-bottom: 35px;
    letter-spacing: 2px;
    font-weight: 300;
}

/* Progress Bar 3D */
.progress-container {
    margin: 35px 0;
}

.progress-info {
    display: flex;
    justify-content: space-between;
    margin-bottom: 12px;
    font-size: 0.95rem;
    color: rgba(255, 255, 255, 0.8);
    font-weight: 500;
    letter-spacing: 1px;
}

.progress-percentage {
    font-weight: 700;
    color: #4e73df;
    text-shadow: 0 0 10px rgba(78, 115, 223, 0.5);
}

.progress-bar {
    width: 100%;
    height: 12px;
    background: rgba(255, 255, 255, 0.08);
    border-radius: 20px;
    overflow: hidden;
    position: relative;
    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.3);
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #4e73df, #1cc88a, #f6c23e, #e74a3b, #4e73df);
    background-size: 300% 100%;
    width: 0%;
    border-radius: 20px;
    transition: width 0.6s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    box-shadow: 0 0 15px rgba(78, 115, 223, 0.5);
    animation: gradientMoveHD 2s linear infinite;
}

@keyframes gradientMoveHD {
    0% { background-position: 0% 0%; }
    100% { background-position: 100% 0%; }
}

.progress-fill::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
    animation: shimmerHD 1.5s infinite;
}

@keyframes shimmerHD {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
}

/* Status Message HD */
.status-message {
    min-height: 80px;
    display: flex;
    align-items: center;
    gap: 18px;
    background: rgba(0, 0, 0, 0.4);
    backdrop-filter: blur(10px);
    border-radius: 25px;
    padding: 18px 28px;
    margin: 25px 0;
    border: 1px solid rgba(78, 115, 223, 0.2);
    transition: all 0.3s;
}

.status-icon {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
}

.status-icon.loading {
    background: rgba(78, 115, 223, 0.2);
    color: #4e73df;
    animation: spinHD 1s linear infinite;
}

@keyframes spinHD {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.status-icon.success {
    background: rgba(28, 200, 138, 0.2);
    color: #1cc88a;
    box-shadow: 0 0 15px rgba(28, 200, 138, 0.3);
}

.status-icon.error {
    background: rgba(231, 74, 59, 0.2);
    color: #e74a3b;
    box-shadow: 0 0 15px rgba(231, 74, 59, 0.3);
}

.status-text {
    flex: 1;
    font-size: 1rem;
    font-weight: 500;
    color: rgba(255, 255, 255, 0.9);
    line-height: 1.5;
}

/* Details Card 3D */
.details-card {
    background: rgba(0, 0, 0, 0.4);
    backdrop-filter: blur(10px);
    border-radius: 35px;
    padding: 28px;
    margin: 28px 0;
    border: 1px solid rgba(78, 115, 223, 0.2);
    transform-origin: center;
    transition: all 0.4s;
}

.details-card:hover {
    border-color: rgba(78, 115, 223, 0.5);
    box-shadow: 0 15px 35px -10px rgba(78, 115, 223, 0.2);
}

.details-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 25px;
    color: #4e73df;
    font-weight: 700;
    letter-spacing: 2px;
    font-size: 0.9rem;
}

.detail-item {
    display: flex;
    align-items: center;
    gap: 18px;
    padding: 14px 0;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    transition: all 0.3s;
}

.detail-item:hover {
    transform: translateX(5px);
}

.detail-icon {
    width: 45px;
    height: 45px;
    border-radius: 15px;
    background: linear-gradient(135deg, rgba(78, 115, 223, 0.2), rgba(28, 200, 138, 0.1));
    display: flex;
    align-items: center;
    justify-content: center;
    color: #4e73df;
    font-size: 20px;
}

.detail-content {
    flex: 1;
}

.detail-label {
    font-size: 0.8rem;
    color: rgba(255, 255, 255, 0.5);
    margin-bottom: 5px;
    letter-spacing: 1px;
}

.detail-value {
    font-size: 1rem;
    font-weight: 600;
    word-break: break-all;
    background: linear-gradient(135deg, #fff, #4e73df);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.detail-value.success {
    background: linear-gradient(135deg, #1cc88a, #4e73df);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

/* Action Buttons 3D */
.action-buttons {
    display: flex;
    gap: 18px;
    margin-top: 35px;
}

.btn {
    flex: 1;
    padding: 16px 28px;
    border-radius: 60px;
    border: none;
    font-weight: 700;
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    text-decoration: none;
    position: relative;
    overflow: hidden;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.btn::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.25);
    transform: translate(-50%, -50%);
    transition: width 0.6s, height 0.6s;
}

.btn:hover::before {
    width: 400px;
    height: 400px;
}

.btn-primary {
    background: linear-gradient(135deg, #4e73df, #224abe);
    color: white;
    box-shadow: 0 15px 25px -10px rgba(78, 115, 223, 0.5);
}

.btn-primary:hover {
    transform: translateY(-5px) scale(1.02);
    box-shadow: 0 25px 35px -12px rgba(78, 115, 223, 0.7);
}

.btn-success {
    background: linear-gradient(135deg, #1cc88a, #16966b);
    color: white;
    box-shadow: 0 15px 25px -10px rgba(28, 200, 138, 0.5);
}

.btn-success:hover {
    transform: translateY(-5px) scale(1.02);
    box-shadow: 0 25px 35px -12px rgba(28, 200, 138, 0.7);
}

.btn-secondary {
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.15);
    color: white;
}

.btn-secondary:hover {
    background: rgba(255, 255, 255, 0.15);
    transform: translateY(-5px);
}

/* Toast Notification HD */
.toast-container {
    position: fixed;
    bottom: 30px;
    right: 30px;
    z-index: 1000;
}

.toast {
    background: rgba(10, 10, 25, 0.95);
    backdrop-filter: blur(20px);
    border-left: 4px solid #4e73df;
    border-radius: 20px;
    padding: 16px 28px;
    margin-top: 12px;
    color: white;
    font-size: 0.9rem;
    transform: translateX(450px);
    transition: transform 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.4);
    display: flex;
    align-items: center;
    gap: 15px;
    min-width: 320px;
    font-weight: 500;
}

.toast.show {
    transform: translateX(0);
}

.toast.success { border-left-color: #1cc88a; }
.toast.error { border-left-color: #e74a3b; }
.toast.warning { border-left-color: #f6c23e; }

.toast i {
    font-size: 22px;
}

/* Responsive */
@media (max-width: 768px) {
    .container {
        padding: 35px 25px;
        margin: 50px 20px;
    }
    
    h2 {
        font-size: 1.8rem;
    }
    
    .action-buttons {
        flex-direction: column;
    }
    
    .header-icons {
        gap: 12px;
    }
    
    .icon-circle {
        width: 55px;
        height: 55px;
        font-size: 22px;
    }
    
    .toast {
        min-width: auto;
        width: calc(100vw - 60px);
    }
}

/* Loading Dot Animation */
.loading-dots::after {
    content: '...';
    animation: dots 1.5s steps(4, end) infinite;
    display: inline-block;
    width: 30px;
    text-align: left;
}

@keyframes dots {
    0%, 20% { content: '.'; }
    40% { content: '..'; }
    60%, 100% { content: '...'; }
}
</style>
</head>
<body>

<!-- Canvas 3D untuk efek Three.js -->
<canvas id="canvas-3d"></canvas>

<div class="gradient-overlay"></div>
<div class="orb orb-1"></div>
<div class="orb orb-2"></div>
<div class="orb orb-3"></div>

<div class="toast-container" id="toastContainer"></div>

<div class="container">
    <div class="header-icons">
        <div class="icon-circle"><i class="fas fa-rocket"></i></div>
        <div class="icon-circle"><i class="fas fa-crown"></i></div>
        <div class="icon-circle"><i class="fas fa-shield-alt"></i></div>
        <div class="icon-circle"><i class="fas fa-bolt"></i></div>
    </div>
    
    <h2 class="glow-text">⚡ PANEL SIAP! ⚡</h2>
    <p class="subtitle">Memproses panel premium Ultra Anda...</p>
    
    <div class="progress-container">
        <div class="progress-info">
            <span><i class="fas fa-chart-line"></i> Progress Deployment</span>
            <span class="progress-percentage" id="progressPercentage">0%</span>
        </div>
        <div class="progress-bar">
            <div class="progress-fill" id="progressFill"></div>
        </div>
    </div>
    
    <div class="status-message" id="statusMessage">
        <div class="status-icon loading" id="statusIcon">
            <i class="fas fa-spinner"></i>
        </div>
        <div class="status-text" id="statusText">⏳ Menyiapkan data panel anda...</div>
    </div>
    
    <div class="details-card" id="details" style="display: none;">
        <div class="details-header">
            <i class="fas fa-cube"></i>
            <span>INFORMASI PANEL ULTRA</span>
        </div>
        
        <div class="detail-item">
            <div class="detail-icon"><i class="fas fa-folder-tree"></i></div>
            <div class="detail-content">
                <div class="detail-label">FOLDER NAME</div>
                <div class="detail-value" id="folderName">ranzz_panel</div>
            </div>
        </div>
        
        <div class="detail-item">
            <div class="detail-icon"><i class="fas fa-globe"></i></div>
            <div class="detail-content">
                <div class="detail-label">API ENDPOINT</div>
                <div class="detail-value" id="apiLink">https://panel.ranzz.com/api/</div>
            </div>
        </div>
        
        <div class="detail-item">
            <div class="detail-icon"><i class="fas fa-bolt"></i></div>
            <div class="detail-content">
                <div class="detail-label">AUTO CONNECT </div>
                <div class="detail-value success" id="autoConnectStatus">Active • Mode</div>
            </div>
        </div>
    </div>
    
    <div class="action-buttons" id="actionButtons" style="display: none;">
        <a href="#" class="btn btn-primary" id="gotoPanelBtn">
            <i class="fas fa-rocket"></i> Launch Panel 
        </a>
        <button class="btn btn-secondary" id="copyApiBtn">
            <i class="fas fa-copy"></i> Copy API
        </button>
    </div>
</div>

<script type="module">
    import * as THREE from 'three';

    // === THREE.JS 3D BACKGROUND ULTRA HD ===
    const canvas = document.getElementById('canvas-3d');
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x050510);
    scene.fog = new THREE.FogExp2(0x050510, 0.0005);

    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 2, 8);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ canvas, alpha: false, antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);

    // === LIGHTS 3D ===
    const ambientLight = new THREE.AmbientLight(0x223366);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(2, 5, 3);
    scene.add(directionalLight);

    const backLight = new THREE.PointLight(0x4e73df, 0.5);
    backLight.position.set(0, 0, -5);
    scene.add(backLight);

    const colorLight = new THREE.PointLight(0xff33ff, 0.3);
    colorLight.position.set(3, 2, 4);
    scene.add(colorLight);

    // === MAIN 3D OBJECT ===
    // Torus Knot 3D (Centerpiece)
    const geometry = new THREE.TorusKnotGeometry(1.2, 0.3, 200, 32, 3, 4);
    const material = new THREE.MeshStandardMaterial({
        color: 0x4e73df,
        emissive: 0x1a2a6a,
        emissiveIntensity: 0.5,
        metalness: 0.8,
        roughness: 0.2,
        wireframe: false
    });
    const torusKnot = new THREE.Mesh(geometry, material);
    scene.add(torusKnot);

    // Glow effect menggunakan Sphere dengan opacity rendah
    const glowGeometry = new THREE.SphereGeometry(1.5, 32, 32);
    const glowMaterial = new THREE.MeshBasicMaterial({
        color: 0x4e73df,
        transparent: true,
        opacity: 0.08,
        side: THREE.BackSide
    });
    const glowSphere = new THREE.Mesh(glowGeometry, glowMaterial);
    scene.add(glowSphere);

    // Floating particles system
    const particleCount = 1500;
    const particlesGeometry = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
        particlePositions[i * 3] = (Math.random() - 0.5) * 40;
        particlePositions[i * 3 + 1] = (Math.random() - 0.5) * 20;
        particlePositions[i * 3 + 2] = (Math.random() - 0.5) * 30 - 15;
    }
    particlesGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particlesMaterial = new THREE.PointsMaterial({
        color: 0x4e73df,
        size: 0.05,
        transparent: true,
        opacity: 0.6,
        blending: THREE.AdditiveBlending
    });
    const particles = new THREE.Points(particlesGeometry, particlesMaterial);
    scene.add(particles);

    // Stars background
    const starCount = 800;
    const starGeometry = new THREE.BufferGeometry();
    const starPositions = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
        starPositions[i * 3] = (Math.random() - 0.5) * 200;
        starPositions[i * 3 + 1] = (Math.random() - 0.5) * 100;
        starPositions[i * 3 + 2] = (Math.random() - 0.5) * 80 - 40;
    }
    starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    const starMaterial = new THREE.PointsMaterial({ color: 0xffffff, size: 0.08, transparent: true, opacity: 0.5 });
    const stars = new THREE.Points(starGeometry, starMaterial);
    scene.add(stars);

    // Animation variables
    let time = 0;

    function animate3D() {
        requestAnimationFrame(animate3D);
        time += 0.008;

        torusKnot.rotation.x = time;
        torusKnot.rotation.y = time * 0.7;
        torusKnot.rotation.z = time * 0.5;
        
        glowSphere.rotation.x = time * 0.3;
        glowSphere.rotation.y = time * 0.4;
        
        particles.rotation.y = time * 0.05;
        particles.rotation.x = time * 0.03;
        
        stars.rotation.y = time * 0.02;
        
        // Camera gentle movement
        camera.position.x = Math.sin(time * 0.2) * 0.3;
        camera.position.y = Math.cos(time * 0.3) * 0.2;
        camera.lookAt(0, 0, 0);
        
        renderer.render(scene, camera);
    }
    
    animate3D();

    // Handle window resize
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });
</script>

<script>
// === Toast Notification System ===
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    let icon = '';
    switch(type) {
        case 'success': icon = 'fa-check-circle'; break;
        case 'error': icon = 'fa-exclamation-circle'; break;
        case 'warning': icon = 'fa-exclamation-triangle'; break;
        default: icon = 'fa-info-circle';
    }
    
    toast.innerHTML = `
        <i class="fas ${icon}"></i>
        <span>${message}</span>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            if (container.contains(toast)) container.removeChild(toast);
        }, 500);
    }, 3500);
}

// === GSAP Animations ===
gsap.from('.container', {
    duration: 1.2,
    scale: 0.9,
    opacity: 0,
    y: 50,
    ease: 'back.out(1.2)'
});

gsap.from('.icon-circle', {
    duration: 0.8,
    scale: 0,
    rotationY: 360,
    stagger: 0.1,
    ease: 'back.out(1.5)'
});

// === Main Process Simulation ===
window.addEventListener("DOMContentLoaded", () => {
    const urlParams = new URLSearchParams(window.location.search);
    const web = urlParams.get('web') || 'panel_ranzz_3d';
    const host = window.location.host;
    const scheme = window.location.protocol;
    
    const apiLink = `${scheme}//${host}/${web}/apiii.php`;
    const settingLink = `${scheme}//${host}/${web}/ranzz`;
    
    const progressFill = document.getElementById('progressFill');
    const progressPercentage = document.getElementById('progressPercentage');
    const statusText = document.getElementById('statusText');
    const statusIcon = document.getElementById('statusIcon');
    const detailsEl = document.getElementById('details');
    const actionButtons = document.getElementById('actionButtons');
    const folderSpan = document.getElementById('folderName');
    const apiSpan = document.getElementById('apiLink');
    const gotoPanelBtn = document.getElementById('gotoPanelBtn');
    const copyApiBtn = document.getElementById('copyApiBtn');
    
    let progress = 0;
    
    const updateProgress = (value, message, iconType = 'loading') => {
        progress = value;
        gsap.to(progressFill, {
            width: `${progress}%`,
            duration: 0.5,
            ease: 'power2.out'
        });
        progressPercentage.textContent = `${progress}%`;
        if (message) {
            statusText.innerHTML = message;
        }
        
        statusIcon.className = `status-icon ${iconType}`;
        if (iconType === 'loading') {
            statusIcon.innerHTML = '<i class="fas fa-spinner"></i>';
        } else if (iconType === 'success') {
            statusIcon.innerHTML = '<i class="fas fa-check-circle"></i>';
        } else if (iconType === 'error') {
            statusIcon.innerHTML = '<i class="fas fa-exclamation-circle"></i>';
        }
    };
    
    // Simulasi progress dengan efek 3D HD
    updateProgress(5, '⏳ Mengaktifkan environment Ultra...', 'loading');
    
    setTimeout(() => {
        updateProgress(20, '✓ Membuat folder panel premium...', 'success');
        showToast('✨ Folder panel berhasil dibuat!', 'success');
        
        setTimeout(() => {
            updateProgress(40, '✓ Menginstall file panel...', 'success');
            showToast('📦 File panel  berhasil diinstall!', 'success');
            
            setTimeout(() => {
                updateProgress(60, '✓ Mengaktifkan auto connect  mode...', 'success');
                showToast('🔗 Auto connect berhasil diaktifkan!', 'success');
                
                // Animasi muncul details card
                detailsEl.style.display = 'block';
                folderSpan.textContent = web;
                apiSpan.textContent = apiLink;
                gotoPanelBtn.href = settingLink;
                
                gsap.from('.details-card', {
                    duration: 0.8,
                    scale: 0.9,
                    opacity: 0,
                    y: 30,
                    ease: 'back.out(1.2)'
                });
                
                setTimeout(() => {
                    updateProgress(80, '✓ Menyambungkan ke server pusat...', 'success');
                    showToast('🌐 Koneksi ke server pusat berhasil!', 'success');
                    
                    setTimeout(() => {
                        updateProgress(95, '✓ Finalisasi panel ...', 'success');
                        
                        setTimeout(() => {
                            updateProgress(100, '✨ Panel  Ultra siap digunakan! ✨', 'success');
                            showToast('🎉 Panel siap digunakan! Menuju ke panel...', 'success');
                            
                            // Tampilkan action buttons
                            actionButtons.style.display = 'flex';
                            
                            gsap.from('.action-buttons .btn', {
                                duration: 0.6,
                                scale: 0,
                                opacity: 0,
                                stagger: 0.1,
                                ease: 'back.out(1.5)'
                            });
                            
                            // Auto redirect ke setting link
                            setTimeout(() => {
                                showToast('🚀 Mengalihkan ke panel Anda...', 'success');
                                setTimeout(() => {
                                    window.location.href = settingLink;
                                }, 1500);
                            }, 1500);
                        }, 500);
                    }, 800);
                }, 1000);
            }, 1000);
        }, 1000);
    }, 1000);
    
    // Copy API button
    copyApiBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(apiLink).then(() => {
            showToast('✅ API Link berhasil disalin!', 'success');
        }).catch(() => {
            showToast('❌ Gagal menyalin API', 'error');
        });
    });
});
</script>
</body>
</html>
<?php
session_start();

// CEK MAINTENANCE
$maintenance = file_exists('maintenance.json') ? json_decode(file_get_contents('maintenance.json'), true) : ['status' => false, 'message' => 'Sedang maintenance, coba lagi nanti!'];
if($maintenance['status']) {
    die('
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Maintenance - Aln Jasteb</title>
        <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <style>
            *{margin:0;padding:0;box-sizing:border-box}
            body{background:#050508;font-family:"Space Grotesk",sans-serif;min-height:100vh;display:flex;justify-content:center;align-items:center;overflow:hidden}
            .noise{position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.04'/%3E%3C/svg%3E");opacity:.4;pointer-events:none;z-index:0}
            .orb{position:fixed;border-radius:50%;filter:blur(80px);pointer-events:none}
            .orb1{width:400px;height:400px;background:rgba(255,165,0,.07);top:-100px;left:-100px}
            .orb2{width:300px;height:300px;background:rgba(255,100,0,.05);bottom:-50px;right:-50px}
            .box{position:relative;z-index:1;text-align:center;background:rgba(255,255,255,.03);border:1px solid rgba(255,165,0,.2);border-radius:24px;padding:60px 50px;max-width:480px;margin:20px;backdrop-filter:blur(20px)}
            .box i{font-size:64px;color:#f6a623;margin-bottom:24px;display:block;animation:pulse 2s infinite}
            @keyframes pulse{0%,100%{filter:drop-shadow(0 0 8px #f6a623);}50%{filter:drop-shadow(0 0 24px #f6a623);}}
            h1{color:#fff;font-size:22px;font-weight:600;margin-bottom:12px;letter-spacing:-.5px}
            .msg{background:rgba(246,166,35,.08);border:1px solid rgba(246,166,35,.25);padding:16px 20px;border-radius:14px;color:#f6a623;font-size:14px;font-family:"JetBrains Mono",monospace;margin-top:20px}
            .badge{display:inline-block;background:rgba(246,166,35,.15);color:#f6a623;font-size:11px;font-family:"JetBrains Mono",monospace;letter-spacing:2px;padding:6px 14px;border-radius:100px;border:1px solid rgba(246,166,35,.3);margin-bottom:20px}
        </style>
    </head>
    <body>
        <div class="noise"></div>
        <div class="orb orb1"></div>
        <div class="orb orb2"></div>
        <div class="box">
            <span class="badge">SYSTEM STATUS</span>
            <i class="fas fa-tools"></i>
            <h1>Under Maintenance</h1>
            <p style="color:#666;font-size:14px">Sistem sedang dalam perbaikan. Tunggu sebentar ya.</p>
            <div class="msg">📢 ' . htmlspecialchars($maintenance['message']) . '</div>
        </div>
    </body>
    </html>
    ');
    exit;
}

// Cek percobaan login gagal
$failedAttempts = isset($_SESSION['login_attempts']) ? $_SESSION['login_attempts'] : 0;
$lockoutTime = isset($_SESSION['lockout_time']) ? $_SESSION['lockout_time'] : 0;

if($lockoutTime > time()) {
    $remaining = $lockoutTime - time();
    $error = "Terlalu banyak percobaan. Coba lagi setelah " . ceil($remaining/60) . " menit.";
} elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $key = trim($_POST['key']);
    $keys = file_exists('data_keys.json') ? json_decode(file_get_contents('data_keys.json'), true) : [];
    
    $valid = false;
    foreach($keys as $k) {
        if($k['key'] === $key && strtotime($k['expired']) >= time()) {
            $valid = true;
            $_SESSION['buyer'] = $k['buyer'];
            $_SESSION['buyer_key'] = $key;
            $_SESSION['login_attempts'] = 0;
            $_SESSION['login_time'] = date('Y-m-d H:i:s');
            
            $log = date('Y-m-d H:i:s') . " - Login successful: " . $k['buyer'] . " (" . $_SERVER['REMOTE_ADDR'] . ")\n";
            file_put_contents('login_logs.txt', $log, FILE_APPEND);
            
            header("Location: rambolet.php");
            exit;
        }
    }
    
    if(!$valid) {
        $failedAttempts++;
        $_SESSION['login_attempts'] = $failedAttempts;
        
        $log = date('Y-m-d H:i:s') . " - Login failed: IP " . $_SERVER['REMOTE_ADDR'] . " - Key: " . $key . "\n";
        file_put_contents('failed_logins.txt', $log, FILE_APPEND);
        
        if($failedAttempts >= 5) {
            $_SESSION['lockout_time'] = time() + 900;
            $error = "Terlalu banyak percobaan gagal. Coba lagi 15 menit kemudian.";
        } else {
            $error = "Key tidak valid atau sudah expired. Sisa percobaan: " . (5 - $failedAttempts);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ALN JASTEB — Access Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --accent: #ff8c00;
            --accent2: #ff4500;
            --bg: #050508;
            --surface: rgba(255,255,255,.03);
            --border: rgba(255,140,0,.18);
            --text: #e8e8e8;
            --muted: #555;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            background: var(--bg);
            font-family: 'Space Grotesk', sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            color: var(--text);
        }

        /* Noise texture */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.035'/%3E%3C/svg%3E");
            pointer-events: none;
            z-index: 0;
            opacity: .5;
        }

        /* Ambient orbs */
        .orb {
            position: fixed;
            border-radius: 50%;
            filter: blur(100px);
            pointer-events: none;
            z-index: 0;
        }
        .orb-1 { width: 500px; height: 500px; background: rgba(255,100,0,.06); top: -150px; left: -150px; }
        .orb-2 { width: 400px; height: 400px; background: rgba(255,50,0,.04); bottom: -100px; right: -100px; }
        .orb-3 { width: 200px; height: 200px; background: rgba(255,140,0,.08); top: 40%; left: 50%; transform: translate(-50%,-50%); animation: orbPulse 6s ease-in-out infinite; }

        @keyframes orbPulse {
            0%, 100% { transform: translate(-50%,-50%) scale(1); opacity: .6; }
            50% { transform: translate(-50%,-50%) scale(1.3); opacity: 1; }
        }

        /* Scanlines */
        .scanlines {
            position: fixed;
            inset: 0;
            background: repeating-linear-gradient(
                0deg,
                transparent,
                transparent 2px,
                rgba(0,0,0,.03) 2px,
                rgba(0,0,0,.03) 4px
            );
            pointer-events: none;
            z-index: 0;
        }

        /* Main card */
        .card {
            position: relative;
            z-index: 1;
            width: 420px;
            background: rgba(12, 12, 18, 0.85);
            border: 1px solid var(--border);
            border-radius: 28px;
            padding: 48px 40px;
            backdrop-filter: blur(30px);
            animation: cardIn .7s cubic-bezier(.16,1,.3,1) forwards;
            opacity: 0;
            transform: translateY(24px);
        }

        @keyframes cardIn {
            to { opacity: 1; transform: translateY(0); }
        }

        /* Glow border on hover */
        .card::before {
            content: '';
            position: absolute;
            inset: -1px;
            border-radius: 28px;
            background: linear-gradient(135deg, rgba(255,140,0,.3), transparent 50%, rgba(255,69,0,.2));
            opacity: 0;
            transition: opacity .4s;
            z-index: -1;
        }
        .card:hover::before { opacity: 1; }

        /* Top badge */
        .badge-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 36px;
        }

        .badge {
            display: flex;
            align-items: center;
            gap: 6px;
            background: rgba(255,140,0,.1);
            border: 1px solid rgba(255,140,0,.25);
            border-radius: 100px;
            padding: 5px 12px;
            font-size: 10px;
            font-family: 'JetBrains Mono', monospace;
            letter-spacing: 1.5px;
            color: var(--accent);
            text-transform: uppercase;
        }

        .badge .dot {
            width: 6px;
            height: 6px;
            background: #1cc88a;
            border-radius: 50%;
            box-shadow: 0 0 6px #1cc88a;
            animation: blink 2s infinite;
        }

        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: .3; }
        }

        .version {
            font-size: 10px;
            font-family: 'JetBrains Mono', monospace;
            color: var(--muted);
            letter-spacing: 1px;
        }

        /* Header */
        .header { margin-bottom: 32px; }

        .crown-wrap {
            width: 64px;
            height: 64px;
            background: linear-gradient(135deg, rgba(255,140,0,.15), rgba(255,69,0,.08));
            border: 1px solid rgba(255,140,0,.25);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
            position: relative;
        }

        .crown-wrap::after {
            content: '';
            position: absolute;
            inset: -1px;
            border-radius: 20px;
            background: linear-gradient(135deg, var(--accent), var(--accent2));
            opacity: 0;
            z-index: -1;
            filter: blur(8px);
            transition: opacity .4s;
        }

        .crown-wrap:hover::after { opacity: .6; }

        .crown-wrap i {
            font-size: 28px;
            background: linear-gradient(135deg, #ff8c00, #ff4500);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        h1 {
            font-size: 26px;
            font-weight: 700;
            letter-spacing: -1px;
            color: #fff;
            margin-bottom: 6px;
            line-height: 1.2;
        }

        h1 span {
            background: linear-gradient(90deg, #ff8c00, #ff4500);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .subtitle {
            font-size: 13px;
            color: var(--muted);
            font-weight: 400;
        }

        /* Divider */
        .divider {
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(255,140,0,.2), transparent);
            margin: 28px 0;
        }

        /* Input */
        .input-wrap {
            position: relative;
            margin-bottom: 14px;
        }

        .input-wrap .icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--muted);
            font-size: 15px;
            transition: color .3s;
            pointer-events: none;
        }

        input[type="text"] {
            width: 100%;
            padding: 15px 18px 15px 48px;
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(255,255,255,.08);
            border-radius: 14px;
            color: #fff;
            font-size: 14px;
            font-family: 'JetBrains Mono', monospace;
            letter-spacing: 1px;
            transition: all .3s;
            outline: none;
        }

        input[type="text"]:focus {
            border-color: rgba(255,140,0,.5);
            background: rgba(255,140,0,.04);
            box-shadow: 0 0 0 3px rgba(255,140,0,.08);
        }

        input[type="text"]:focus + .icon,
        .input-wrap:focus-within .icon {
            color: var(--accent);
        }

        input::placeholder { color: rgba(255,255,255,.2); letter-spacing: 0; }

        /* Button */
        .btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #ff8c00, #cc5500);
            border: none;
            border-radius: 14px;
            color: #fff;
            font-size: 14px;
            font-weight: 600;
            font-family: 'Space Grotesk', sans-serif;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition: all .3s;
            letter-spacing: .5px;
            margin-top: 6px;
        }

        .btn::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(255,255,255,.15), transparent);
            opacity: 0;
            transition: opacity .3s;
        }

        .btn:hover::before { opacity: 1; }
        .btn:hover { transform: translateY(-1px); box-shadow: 0 8px 24px rgba(255,140,0,.3); }
        .btn:active { transform: translateY(0); box-shadow: none; }

        .btn i { margin-right: 8px; }

        /* Error */
        .error-box {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            background: rgba(231,74,59,.08);
            border: 1px solid rgba(231,74,59,.25);
            border-radius: 12px;
            padding: 13px 16px;
            margin-top: 14px;
            animation: shake .4s ease;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            20% { transform: translateX(-6px); }
            40% { transform: translateX(6px); }
            60% { transform: translateX(-3px); }
            80% { transform: translateX(3px); }
        }

        .error-box i { color: #e74a3b; font-size: 14px; margin-top: 1px; flex-shrink: 0; }
        .error-box span { font-size: 12px; color: #e74a3b; line-height: 1.5; }

        /* Footer stats */
        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-top: 28px;
            padding-top: 24px;
            border-top: 1px solid rgba(255,255,255,.05);
        }

        .stat {
            text-align: center;
            padding: 12px 8px;
            background: rgba(255,255,255,.02);
            border: 1px solid rgba(255,255,255,.05);
            border-radius: 12px;
            transition: all .3s;
            cursor: default;
        }

        .stat:hover {
            background: rgba(255,140,0,.06);
            border-color: rgba(255,140,0,.2);
        }

        .stat i { font-size: 16px; color: var(--accent); margin-bottom: 6px; display: block; }
        .stat-label { font-size: 10px; color: var(--muted); letter-spacing: .5px; }

        /* Footer */
        .footer-text {
            text-align: center;
            margin-top: 20px;
            font-size: 11px;
            color: rgba(255,255,255,.15);
            font-family: 'JetBrains Mono', monospace;
            letter-spacing: 1px;
        }

        /* Responsive */
        @media (max-width: 460px) {
            .card { width: 92%; padding: 36px 26px; }
            h1 { font-size: 22px; }
        }
    </style>
</head>
<body>
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
    <div class="orb orb-3"></div>
    <div class="scanlines"></div>

    <div class="card">
        <div class="badge-row">
            <div class="badge">
                <div class="dot"></div>
                System Online
            </div>
            <span class="version">v2.0</span>
        </div>

        <div class="header">
            <div class="crown-wrap">
                <i class="fas fa-crown"></i>
            </div>
            <h1>ALN <span>JASTEB</span></h1>
            <p class="subtitle">Premium Panel · Super Quality</p>
        </div>

        <div class="divider"></div>

        <form method="POST">
            <div class="input-wrap">
                <input type="text" name="key" placeholder="Masukkan kode key dari admin" autocomplete="off" required>
                <i class="fas fa-key icon"></i>
            </div>
            <button type="submit" class="btn">
                <i class="fas fa-arrow-right-to-bracket"></i>
                Masuk Sekarang
            </button>
        </form>

        <?php if(isset($error)): ?>
        <div class="error-box">
            <i class="fas fa-triangle-exclamation"></i>
            <span><?= htmlspecialchars($error) ?></span>
        </div>
        <?php endif; ?>

        <div class="stats">
            <div class="stat">
                <i class="fas fa-shield-halved"></i>
                <div class="stat-label">Secure</div>
            </div>
            <div class="stat">
                <i class="fas fa-bolt"></i>
                <div class="stat-label">Fast</div>
            </div>
            <div class="stat">
                <i class="fas fa-headset"></i>
                <div class="stat-label">Support</div>
            </div>
        </div>
    </div>

    <div class="footer-text">ALN HOST PREMIUM · RES DERES</div>

    <script>
    // Subtle input interaction
    const input = document.querySelector('input[type="text"]');
    input.addEventListener('input', function() {
        this.style.letterSpacing = this.value.length > 0 ? '2px' : '0';
    });
    </script>
</body>
</html>

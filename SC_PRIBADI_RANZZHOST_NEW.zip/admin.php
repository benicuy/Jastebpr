<?php
session_start();
if(!isset($_SESSION['admin'])) {
    header("Location: key.php");
    exit;
}

$keysFile = 'data_keys.json';
$panelsFile = 'data_panels.json';
$blockedFile = 'blocked_panels.json';

// Load data
$keys = file_exists($keysFile) ? json_decode(file_get_contents($keysFile), true) : [];
$panels = file_exists($panelsFile) ? json_decode(file_get_contents($panelsFile), true) : [];
$blockedPanels = file_exists($blockedFile) ? json_decode(file_get_contents($blockedFile), true) : [];

$msg = '';
$error = '';

// Create key
if(isset($_POST['create_key'])) {
    $buyer = trim($_POST['buyer_name']);
    $expired = $_POST['expired_date'];
    $new_key = strtoupper(substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 12));
    $keys[] = ['key' => $new_key, 'buyer' => $buyer, 'expired' => $expired, 'created' => date('Y-m-d H:i:s')];
    file_put_contents($keysFile, json_encode($keys, JSON_PRETTY_PRINT));
    $msg = "✅ Key $new_key berhasil dibuat untuk $buyer (Expired: $expired)";
}

// Edit expired buyer
if(isset($_POST['edit_expired'])) {
    $old_key = $_POST['old_key'];
    $new_expired = $_POST['new_expired'];
    foreach($keys as &$k) {
        if($k['key'] === $old_key) {
            $k['expired'] = $new_expired;
            break;
        }
    }
    file_put_contents($keysFile, json_encode($keys, JSON_PRETTY_PRINT));
    $msg = "✅ Expired key $old_key diubah menjadi $new_expired";
}

// Delete key
if(isset($_GET['delete_key'])) {
    $key_to_delete = $_GET['delete_key'];
    $keys = array_filter($keys, function($k) use($key_to_delete) {
        return $k['key'] !== $key_to_delete;
    });
    file_put_contents($keysFile, json_encode(array_values($keys), JSON_PRETTY_PRINT));
    $msg = "🗑️ Key $key_to_delete berhasil dihapus";
    header("Location: admin.php?msg=".urlencode($msg));
    exit;
}

// Blokir panel
if(isset($_GET['block_panel'])) {
    $panel_name = $_GET['block_panel'];
    $reason = isset($_GET['reason']) ? $_GET['reason'] : 'Melanggar aturan';
    if(!in_array($panel_name, $blockedPanels)) {
        $blockedPanels[] = ['name' => $panel_name, 'reason' => $reason, 'blocked_at' => date('Y-m-d H:i:s')];
        file_put_contents($blockedFile, json_encode($blockedPanels, JSON_PRETTY_PRINT));
        $msg = "🔒 Panel $panel_name berhasil diblokir! Alasan: $reason";
    } else {
        $msg = "⚠️ Panel $panel_name sudah diblokir sebelumnya!";
    }
    header("Location: admin.php?msg=".urlencode($msg));
    exit;
}

// Buka blokir panel
if(isset($_GET['unblock_panel'])) {
    $panel_name = $_GET['unblock_panel'];
    $blockedPanels = array_filter($blockedPanels, function($b) use($panel_name) {
        return $b['name'] !== $panel_name;
    });
    file_put_contents($blockedFile, json_encode(array_values($blockedPanels), JSON_PRETTY_PRINT));
    $msg = "🔓 Panel $panel_name berhasil dibuka blokirnya!";
    header("Location: admin.php?msg=".urlencode($msg));
    exit;
}

// Hapus panel (dengan pengecekan blokir)
if(isset($_GET['delete_panel'])) {
    $panel_name = $_GET['delete_panel'];
    $panel_path = __DIR__ . '/' . $panel_name;
    if(is_dir($panel_path)) {
        function deleteDir($dir) {
            $files = array_diff(scandir($dir), ['.','..']);
            foreach($files as $file) {
                (is_dir("$dir/$file")) ? deleteDir("$dir/$file") : unlink("$dir/$file");
            }
            return rmdir($dir);
        }
        deleteDir($panel_path);
        $panels = array_filter($panels, function($p) use($panel_name) {
            return $p['nama'] != $panel_name;
        });
        file_put_contents($panelsFile, json_encode(array_values($panels), JSON_PRETTY_PRINT));
        
        // Hapus dari daftar blokir jika ada
        $blockedPanels = array_filter($blockedPanels, function($b) use($panel_name) {
            return $b['name'] !== $panel_name;
        });
        file_put_contents($blockedFile, json_encode(array_values($blockedPanels), JSON_PRETTY_PRINT));
        
        $msg = "🗑️ Panel $panel_name berhasil dihapus!";
        header("Location: admin.php?msg=".urlencode($msg));
        exit;
    }
}

// Set maintenance
if(isset($_POST['set_maintenance'])) {
    $status = $_POST['maintenance_status'];
    $message = $_POST['maintenance_message'];
    file_put_contents('maintenance.json', json_encode(['status' => $status == '1', 'message' => $message]));
    $msg = "🔧 Maintenance mode: ".($status ? 'ON' : 'OFF');
}

// Get maintenance status
$maintenance = file_exists('maintenance.json') ? json_decode(file_get_contents('maintenance.json'), true) : ['status' => false, 'message' => 'Sedang maintenance, kembali lagi nanti!'];

// Hitung statistik
$total_keys = count($keys);
$active_keys = 0;
$expired_keys = 0;
foreach($keys as $k) {
    if(strtotime($k['expired']) >= time()) {
        $active_keys++;
    } else {
        $expired_keys++;
    }
}
$total_panels = count($panels);
$total_blocked = count($blockedPanels);
?>
<!DOCTYPE html>
<html>
<head>
    <title>⚡ 𝘼𝘿𝙈𝙄𝙉 𝙋𝘼𝙉𝙀𝙇 𝙍𝘼𝙉𝙕𝙕 3𝘿 𝙇𝙀𝘿 ⚡</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        
        body { 
            background: linear-gradient(135deg, #0a0a0a 0%, #1a0a2e 50%, #0a0a0a 100%);
            font-family: 'Orbitron', monospace;
            color: #fff;
            padding: 20px;
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
        }
        
        /* 3D Grid Background */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(102, 255, 255, 0.05) 1px, transparent 1px),
                linear-gradient(90deg, rgba(102, 255, 255, 0.05) 1px, transparent 1px);
            background-size: 50px 50px;
            pointer-events: none;
            z-index: 0;
            animation: gridMove 20s linear infinite;
        }
        
        @keyframes gridMove {
            0% { transform: translateY(0); }
            100% { transform: translateY(50px); }
        }
        
        /* Animated LED Particles */
        body::after {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at 20% 50%, rgba(102, 255, 255, 0.1) 0%, transparent 50%);
            pointer-events: none;
            animation: pulseGlow 4s ease-in-out infinite;
            z-index: 0;
        }
        
        @keyframes pulseGlow {
            0%, 100% { opacity: 0.3; transform: scale(1); }
            50% { opacity: 0.8; transform: scale(1.05); }
        }
        
        .container { 
            max-width: 1400px; 
            margin: 0 auto; 
            position: relative;
            z-index: 1;
        }
        
        /* 3D Card Effect */
        .card { 
            background: rgba(10, 10, 26, 0.85);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(102, 255, 255, 0.3);
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 30px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.1);
        }
        
        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(102, 255, 255, 0.1), transparent);
            transition: left 0.5s;
        }
        
        .card:hover::before {
            left: 100%;
        }
        
        .card:hover {
            transform: translateY(-5px) rotateX(2deg);
            box-shadow: 0 20px 40px rgba(102, 255, 255, 0.2);
            border-color: rgba(102, 255, 255, 0.8);
        }
        
        /* LED Neon Border */
        .card::after {
            content: '';
            position: absolute;
            top: -2px;
            left: -2px;
            right: -2px;
            bottom: -2px;
            background: linear-gradient(45deg, #66ffff, #ff33ff, #66ffff, #ff33ff);
            background-size: 200% 200%;
            border-radius: 20px;
            opacity: 0;
            z-index: -1;
            transition: opacity 0.3s;
            animation: borderGlow 3s ease infinite;
        }
        
        @keyframes borderGlow {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        
        .card:hover::after {
            opacity: 0.3;
        }
        
        h2 { 
            color: #66ffff;
            margin-bottom: 20px;
            border-left: 4px solid #66ffff;
            padding-left: 15px;
            text-shadow: 0 0 10px rgba(102, 255, 255, 0.5);
            position: relative;
            display: inline-block;
        }
        
        h2::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, #66ffff, #ff33ff, transparent);
        }
        
        /* 3D Input Fields */
        input, select, textarea { 
            background: rgba(0, 0, 0, 0.6);
            border: 1px solid rgba(102, 255, 255, 0.3);
            color: #fff;
            padding: 12px;
            border-radius: 10px;
            width: 100%;
            margin-bottom: 15px;
            transition: all 0.3s;
            font-family: 'Orbitron', monospace;
        }
        
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #66ffff;
            box-shadow: 0 0 15px rgba(102, 255, 255, 0.3), inset 0 0 5px rgba(102, 255, 255, 0.2);
            transform: scale(1.02);
        }
        
        /* 3D LED Buttons */
        button { 
            background: linear-gradient(135deg, #66ffff, #33cccc);
            color: #000;
            border: none;
            padding: 12px 25px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: bold;
            margin-right: 10px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-family: 'Orbitron', monospace;
            box-shadow: 0 5px 15px rgba(102, 255, 255, 0.3);
        }
        
        button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s;
        }
        
        button:hover::before {
            left: 100%;
        }
        
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 255, 255, 0.5);
        }
        
        button:active {
            transform: translateY(0);
        }
        
        button.danger { 
            background: linear-gradient(135deg, #e74a3b, #c0392b);
            box-shadow: 0 5px 15px rgba(231, 74, 59, 0.3);
        }
        
        button.success { 
            background: linear-gradient(135deg, #ff33ff, #cc33cc);
            box-shadow: 0 5px 15px rgba(255, 51, 255, 0.3);
        }
        
        button.warning {
            background: linear-gradient(135deg, #f6c23e, #d4a017);
            box-shadow: 0 5px 15px rgba(246, 194, 62, 0.3);
        }
        
        /* Glitch Text Effect */
        h1 {
            font-size: 2.5em;
            position: relative;
            animation: glitch 3s infinite;
            background: linear-gradient(135deg, #66ffff, #ff33ff);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        @keyframes glitch {
            0%, 100% { transform: skew(0deg, 0deg); text-shadow: none; }
            95% { transform: skew(0deg, 0deg); text-shadow: none; }
            96% { transform: skew(2deg, 1deg); text-shadow: -2px 0 #ff33ff, 2px 0 #66ffff; }
            97% { transform: skew(-1deg, -2deg); text-shadow: 2px 0 #ff33ff, -2px 0 #66ffff; }
            98% { transform: skew(0deg, 0deg); text-shadow: none; }
        }
        
        /* 3D Table */
        table { 
            width: 100%; 
            border-collapse: collapse;
            position: relative;
        }
        
        th, td { 
            padding: 12px; 
            text-align: left; 
            border-bottom: 1px solid rgba(102, 255, 255, 0.2);
            transition: all 0.3s;
        }
        
        tr:hover {
            background: rgba(102, 255, 255, 0.05);
            transform: scale(1.01);
        }
        
        th { 
            color: #66ffff;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 900;
        }
        
        /* LED Badges */
        .badge { 
            padding: 5px 12px; 
            border-radius: 20px; 
            font-size: 11px;
            font-weight: bold;
            display: inline-block;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.8; transform: scale(1.05); }
        }
        
        .badge.success { 
            background: linear-gradient(135deg, #ff33ff, #cc33cc);
            box-shadow: 0 0 10px rgba(255, 51, 255, 0.5);
        }
        
        .badge.danger { 
            background: linear-gradient(135deg, #e74a3b, #c0392b);
            box-shadow: 0 0 10px rgba(231, 74, 59, 0.5);
        }
        
        .badge.warning { 
            background: linear-gradient(135deg, #f6c23e, #d4a017);
            color: #000;
            box-shadow: 0 0 10px rgba(246, 194, 62, 0.5);
        }
        
        .badge.blocked {
            background: linear-gradient(135deg, #000, #333);
            border: 1px solid #e74a3b;
            color: #e74a3b;
            animation: blinkRed 1s infinite;
        }
        
        @keyframes blinkRed {
            0%, 100% { box-shadow: 0 0 5px #e74a3b; }
            50% { box-shadow: 0 0 20px #e74a3b; }
        }
        
        /* 3D Stat Cards */
        .stat-card {
            background: linear-gradient(135deg, rgba(78, 115, 223, 0.2), rgba(102, 255, 255, 0.1));
            border: 1px solid rgba(102, 255, 255, 0.3);
            border-radius: 20px;
            padding: 20px;
            text-align: center;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }
        
        .stat-card:hover {
            transform: translateY(-10px) rotateX(5deg);
            box-shadow: 0 20px 40px rgba(102, 255, 255, 0.2);
        }
        
        .stat-card i {
            font-size: 40px;
            color: #66ffff;
            margin-bottom: 10px;
            display: inline-block;
            animation: float 3s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }
        
        .stat-card h3 { 
            font-size: 32px; 
            margin: 10px 0;
            text-shadow: 0 0 20px rgba(102, 255, 255, 0.5);
        }
        
        /* Search Box */
        .search-box { 
            margin-bottom: 20px; 
            display: flex; 
            gap: 10px;
        }
        
        .search-box input { 
            flex: 1; 
            margin-bottom: 0;
            background: rgba(0, 0, 0, 0.8);
        }
        
        /* Button Small */
        .btn-sm { 
            padding: 5px 12px; 
            font-size: 11px; 
            margin: 2px; 
            display: inline-block; 
            text-decoration: none; 
            border-radius: 8px;
            font-family: 'Orbitron', monospace;
            transition: all 0.3s;
        }
        
        .btn-sm:hover {
            transform: scale(1.05);
        }
        
        .export-btn { 
            background: linear-gradient(135deg, #1cc88a, #17a673);
        }
        
        /* Modal 3D */
        #editModal > div, #blockModal > div {
            background: linear-gradient(135deg, #0a0a1a, #1a0a2e);
            border: 2px solid #66ffff;
            box-shadow: 0 0 50px rgba(102, 255, 255, 0.3);
            transform: scale(0.9);
            animation: modalPopIn 0.3s ease-out forwards;
        }
        
        @keyframes modalPopIn {
            to {
                transform: scale(1);
            }
        }
        
        /* Blocked Panel Row Style */
        .blocked-row {
            background: rgba(231, 74, 59, 0.1);
            border-left: 3px solid #e74a3b;
        }
        
        .blocked-row:hover {
            background: rgba(231, 74, 59, 0.2);
        }
        
        /* Notification Toast */
        .toast-notif {
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #1a0a2e, #0a0a1a);
            border-left: 4px solid #66ffff;
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            z-index: 10000;
            animation: slideInRight 0.5s ease-out;
        }
        
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        /* Responsive */
        @media (max-width:768px) { 
            .grid-2, .grid-3 { grid-template-columns: 1fr; } 
            table { font-size: 11px; } 
            td { word-break: break-all; }
            h1 { font-size: 1.5em; }
        }
        
        /* Scrollbar Styling */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.3);
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, #66ffff, #33cccc);
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, #ff33ff, #cc33cc);
        }
        
        /* Loading Animation */
        .loading {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.95);
            z-index: 9999;
            display: flex;
            justify-content: center;
            align-items: center;
            animation: fadeOut 0.5s ease-out 1s forwards;
        }
        
        @keyframes fadeOut {
            to {
                opacity: 0;
                visibility: hidden;
            }
        }
        
        .loader {
            width: 60px;
            height: 60px;
            border: 3px solid rgba(102, 255, 255, 0.3);
            border-top: 3px solid #66ffff;
            border-right: 3px solid #ff33ff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* Floating particles */
        .particle {
            position: fixed;
            width: 2px;
            height: 2px;
            background: #66ffff;
            border-radius: 50%;
            pointer-events: none;
            animation: floatParticle 10s linear infinite;
            z-index: 0;
        }
        
        @keyframes floatParticle {
            0% {
                transform: translateY(100vh) translateX(0);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateY(-100vh) translateX(100px);
                opacity: 0;
            }
        }
    </style>
</head>
<body>

<!-- Loading Animation -->
<div class="loading" id="loading">
    <div class="loader"></div>
</div>

<!-- Floating Particles -->
<script>
for(let i = 0; i < 50; i++) {
    let particle = document.createElement('div');
    particle.className = 'particle';
    particle.style.left = Math.random() * 100 + '%';
    particle.style.animationDelay = Math.random() * 10 + 's';
    particle.style.animationDuration = 5 + Math.random() * 10 + 's';
    particle.style.width = Math.random() * 3 + 'px';
    particle.style.height = particle.style.width;
    document.body.appendChild(particle);
}
</script>

<div class="container">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:30px; flex-wrap:wrap; gap:15px;">
        <h1><i class="fas fa-crown"></i> ⚡ 𝙍𝘼𝘼𝙉𝙕𝙕 3𝘿 𝙇𝙀𝘿 𝘼𝘿𝙈𝙄𝙉 ⚡</h1>
        <div>
            <a href="logout.php"><button class="danger"><i class="fas fa-sign-out-alt"></i> LOGOUT</button></a>
        </div>
    </div>
    
    <?php if(isset($_GET['msg'])): ?>
        <div class="toast-notif" id="toastMsg">
            <i class="fas fa-bell"></i> <?= htmlspecialchars($_GET['msg']) ?>
        </div>
        <script>
            setTimeout(() => {
                let toast = document.getElementById('toastMsg');
                if(toast) toast.style.display = 'none';
            }, 3000);
        </script>
    <?php endif; ?>
    
    <!-- STATISTIK 3D LED -->
    <div class="grid-3">
        <div class="stat-card">
            <i class="fas fa-users"></i>
            <h3><?= $total_keys ?></h3>
            <p>Total Buyer</p>
            <div style="width: 100%; height: 2px; background: linear-gradient(90deg, transparent, #66ffff, transparent); margin-top: 10px;"></div>
        </div>
        <div class="stat-card">
            <i class="fas fa-check-circle"></i>
            <h3><?= $active_keys ?></h3>
            <p>Aktif</p>
            <div style="width: 100%; height: 2px; background: linear-gradient(90deg, transparent, #ff33ff, transparent); margin-top: 10px;"></div>
        </div>
        <div class="stat-card">
            <i class="fas fa-folder"></i>
            <h3><?= $total_panels ?></h3>
            <p>Total Panel</p>
            <div style="width: 100%; height: 2px; background: linear-gradient(90deg, transparent, #66ffff, transparent); margin-top: 10px;"></div>
        </div>
        <div class="stat-card">
            <i class="fas fa-ban"></i>
            <h3><?= $total_blocked ?></h3>
            <p>Panel Diblokir</p>
            <div style="width: 100%; height: 2px; background: linear-gradient(90deg, transparent, #e74a3b, transparent); margin-top: 10px;"></div>
        </div>
    </div>
    
    <div class="grid-2">
        <!-- CREATE KEY -->
        <div class="card">
            <h2><i class="fas fa-key"></i> CREATE KEY</h2>
            <form method="POST">
                <input type="text" name="buyer_name" placeholder="📝 Nama Buyer" required>
                <input type="date" name="expired_date" required>
                <button type="submit" name="create_key"><i class="fas fa-plus"></i> CREATE KEY</button>
            </form>
        </div>
        
        <!-- MAINTENANCE -->
        <div class="card">
            <h2><i class="fas fa-wrench"></i> MAINTENANCE MODE</h2>
            <form method="POST">
                <select name="maintenance_status">
                    <option value="1" <?= $maintenance['status'] ? 'selected' : '' ?>>🔴 ON - Maintenance</option>
                    <option value="0" <?= !$maintenance['status'] ? 'selected' : '' ?>>🟢 OFF - Normal</option>
                </select>
                <textarea name="maintenance_message" rows="3" placeholder="💬 Pesan maintenance..."><?= htmlspecialchars($maintenance['message']) ?></textarea>
                <button type="submit" name="set_maintenance"><i class="fas fa-save"></i> APPLY</button>
            </form>
        </div>
    </div>
    
    <!-- LIST KEYS -->
    <div class="card">
        <h2><i class="fas fa-users"></i> LIST KEYS & BUYER</h2>
        <div class="search-box">
            <input type="text" id="searchKey" placeholder="🔍 Cari key atau buyer..." onkeyup="filterKeys()">
            <button onclick="exportKeys()" class="export-btn" style="padding:8px 15px;"><i class="fas fa-download"></i> Export</button>
        </div>
        <div style="overflow-x:auto;">
            <table id="keysTable">
                <thead>
                    <tr><th>🔑 Key</th><th>👤 Buyer</th><th>📅 Expired</th><th>⚡ Status</th><th>🕒 Created</th><th>⚙️ Action</th></tr>
                </thead>
                <tbody>
                    <?php foreach($keys as $k): ?>
                    <tr class="key-row">
                        <td><code style="color:#66ffff;"><?= $k['key'] ?></code></td>
                        <td class="buyer-name"><?= htmlspecialchars($k['buyer']) ?></td>
                        <td><?= $k['expired'] ?></td>
                        <td><span class="badge <?= strtotime($k['expired']) >= time() ? 'success' : 'danger' ?>"><?= strtotime($k['expired']) >= time() ? 'ACTIVE' : 'EXPIRED' ?></span></td>
                        <td><?= $k['created'] ?></td>
                        <td>
                            <button onclick="editExpired('<?= $k['key'] ?>', '<?= $k['expired'] ?>')" class="btn-sm" style="background:#f6c23e; color:#000;"><i class="fas fa-edit"></i> Edit</button>
                            <a href="?delete_key=<?= urlencode($k['key']) ?>" onclick="return confirm('⚠️ Hapus key <?= $k['key'] ?>?')"><button class="btn-sm danger"><i class="fas fa-trash"></i> Hapus</button></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- LIST PANELS WITH BLOCK FEATURE -->
    <div class="card">
        <h2><i class="fas fa-folder"></i> LIST PANEL BUYER <span style="font-size:12px; background:#e74a3b20; padding:5px 10px; border-radius:10px;"><i class="fas fa-ban"></i> Fitur Blokir Panel</span></h2>
        <div class="search-box">
            <input type="text" id="searchPanel" placeholder="🔍 Cari nama panel..." onkeyup="filterPanels()">
        </div>
        <div style="overflow-x:auto;">
            <table id="panelsTable">
                <thead>
                    <tr><th>📁 Nama Panel</th><th>🔗 API Link</th><th>📅 Created</th><th>🔒 Status</th><th>⚙️ Action</th></tr>
                </thead>
                <tbody>
                    <?php 
                    $dirs = array_filter(glob(__DIR__ . '/*'), 'is_dir');
                    foreach($dirs as $dir):
                        $name = basename($dir);
                        if(in_array($name, ['ramzz', 'assets', 'css', 'js', 'audio', 'ramz', 'node_modules'])) continue;
                        $apiii = $dir . '/apiii.php';
                        $created = file_exists($dir . '/created.txt') ? file_get_contents($dir . '/created.txt') : date('Y-m-d H:i:s', filectime($dir));
                        $isBlocked = false;
                        $blockReason = '';
                        foreach($blockedPanels as $bp) {
                            if($bp['name'] === $name) {
                                $isBlocked = true;
                                $blockReason = $bp['reason'];
                                break;
                            }
                        }
                    ?>
                    <tr class="panel-row <?= $isBlocked ? 'blocked-row' : '' ?>">
                        <td><?= $name ?> 
                            <?php if($isBlocked): ?>
                                <span class="badge blocked" style="font-size:9px; margin-left:5px;"><i class="fas fa-ban"></i> BLOCKED</span>
                            <?php endif; ?>
                        </td>
                        <td><a href="<?= $name ?>/apiii.php" target="_blank" style="color:#66ffff;">🚀 <?= $name ?>/apiii.php</a></td>
                        <td><?= $created ?></td>
                        <td>
                            <?php if($isBlocked): ?>
                                <span class="badge danger" style="cursor:help;" title="Alasan: <?= htmlspecialchars($blockReason) ?>">
                                    <i class="fas fa-lock"></i> Diblokir
                                </span>
                            <?php else: ?>
                                <span class="badge success"><i class="fas fa-check"></i> Aktif</span>
                            <?php endif; ?>
                         </td>
                        <td>
                            <a href="<?= $name ?>" target="_blank"><button class="btn-sm" style="background:#4e73df;"><i class="fas fa-eye"></i> Lihat</button></a>
                            
                            <?php if($isBlocked): ?>
                                <a href="?unblock_panel=<?= urlencode($name) ?>" onclick="return confirm('🔓 Buka blokir panel <?= $name ?>?')">
                                    <button class="btn-sm success"><i class="fas fa-unlock-alt"></i> Buka Blokir</button>
                                </a>
                            <?php else: ?>
                                <button onclick="showBlockModal('<?= $name ?>')" class="btn-sm warning"><i class="fas fa-ban"></i> Blokir</button>
                            <?php endif; ?>
                            
                            <a href="?delete_panel=<?= urlencode($name) ?>" onclick="return confirm('⚠️ Hapus panel <?= $name ?> beserta isinya?')">
                                <button class="btn-sm danger"><i class="fas fa-trash"></i> Hapus</button>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- DAFTAR PANEL YANG DIBLOKIR -->
    <?php if(count($blockedPanels) > 0): ?>
    <div class="card" style="border-color:#e74a3b;">
        <h2 style="color:#e74a3b;"><i class="fas fa-ban"></i> PANEL TERBLOKIR</h2>
        <div style="overflow-x:auto;">
            <table>
                <thead>
                    <tr><th>📁 Nama Panel</th><th>📝 Alasan Blokir</th><th>📅 Tanggal Blokir</th><th>⚙️ Action</th></tr>
                </thead>
                <tbody>
                    <?php foreach($blockedPanels as $bp): ?>
                    <tr>
                        <td><?= $bp['name'] ?></td>
                        <td><span style="color:#e74a3b;">🚫 <?= htmlspecialchars($bp['reason']) ?></span></td>
                        <td><?= $bp['blocked_at'] ?></td>
                        <td>
                            <a href="?unblock_panel=<?= urlencode($bp['name']) ?>" onclick="return confirm('🔓 Buka blokir panel <?= $bp['name'] ?>?')">
                                <button class="btn-sm success"><i class="fas fa-unlock-alt"></i> Buka Blokir</button>
                            </a>
                         </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Modal Edit Expired -->
<div id="editModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.9); z-index:1000; justify-content:center; align-items:center;">
    <div style="background:linear-gradient(135deg, #0a0a1a, #1a0a2e); border:2px solid #66ffff; border-radius:20px; padding:30px; width:400px; box-shadow:0 0 50px rgba(102,255,255,0.3);">
        <h3 style="color:#66ffff; margin-bottom:20px;"><i class="fas fa-calendar-edit"></i> Edit Expired Key</h3>
        <form method="POST">
            <input type="hidden" name="old_key" id="edit_old_key">
            <label>📅 Tanggal Expired Baru:</label>
            <input type="date" name="new_expired" id="edit_new_expired" required>
            <div style="margin-top:20px; display:flex; gap:10px;">
                <button type="submit" name="edit_expired" style="background:#1cc88a;"><i class="fas fa-save"></i> Simpan</button>
                <button type="button" onclick="closeModal()" style="background:#e74a3b;"><i class="fas fa-times"></i> Batal</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Block Panel -->
<div id="blockModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.95); z-index:1000; justify-content:center; align-items:center;">
    <div style="background:linear-gradient(135deg, #0a0a1a, #1a0a2e); border:2px solid #e74a3b; border-radius:20px; padding:30px; width:450px; box-shadow:0 0 50px rgba(231,74,59,0.3);">
        <h3 style="color:#e74a3b; margin-bottom:20px;"><i class="fas fa-ban"></i> BLOKIR PANEL</h3>
        <p style="margin-bottom:15px;">Panel: <strong id="blockPanelName" style="color:#66ffff;"></strong></p>
        <label>📝 Alasan Blokir:</label>
        <textarea id="blockReason" rows="3" style="width:100%; padding:10px; border-radius:10px; background:#000; color:#fff; border:1px solid #e74a3b;" placeholder="Contoh: Melanggar aturan, Spam, Dll..."></textarea>
        <div style="margin-top:20px; display:flex; gap:10px;">
            <button onclick="confirmBlock()" style="background:#e74a3b;"><i class="fas fa-ban"></i> BLOKIR PANEL</button>
            <button type="button" onclick="closeBlockModal()" style="background:#666;"><i class="fas fa-times"></i> Batal</button>
        </div>
        <p style="margin-top:15px; font-size:11px; color:#888;"><i class="fas fa-info-circle"></i> Panel yang diblokir akan menampilkan halaman peringatan saat diakses</p>
    </div>
</div>

<script>
// Hilangkan loading setelah halaman load
window.addEventListener('load', function() {
    setTimeout(function() {
        var loading = document.getElementById('loading');
        if(loading) {
            loading.style.display = 'none';
        }
    }, 1000);
});

let currentBlockPanel = '';

function editExpired(key, expired) {
    document.getElementById('edit_old_key').value = key;
    document.getElementById('edit_new_expired').value = expired;
    document.getElementById('editModal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('editModal').style.display = 'none';
}

function showBlockModal(panelName) {
    currentBlockPanel = panelName;
    document.getElementById('blockPanelName').innerText = panelName;
    document.getElementById('blockReason').value = '';
    document.getElementById('blockModal').style.display = 'flex';
}

function closeBlockModal() {
    document.getElementById('blockModal').style.display = 'none';
    currentBlockPanel = '';
}

function confirmBlock() {
    let reason = document.getElementById('blockReason').value;
    if(reason.trim() === '') {
        alert('⚠️ Harap masukkan alasan blokir!');
        return;
    }
    window.location.href = '?block_panel=' + encodeURIComponent(currentBlockPanel) + '&reason=' + encodeURIComponent(reason);
}

function filterKeys() {
    let search = document.getElementById('searchKey').value.toLowerCase();
    let rows = document.querySelectorAll('#keysTable .key-row');
    rows.forEach(row => {
        let buyer = row.querySelector('.buyer-name')?.innerText.toLowerCase() || '';
        let key = row.querySelector('code')?.innerText.toLowerCase() || '';
        row.style.display = (buyer.includes(search) || key.includes(search)) ? '' : 'none';
    });
}

function filterPanels() {
    let search = document.getElementById('searchPanel').value.toLowerCase();
    let rows = document.querySelectorAll('#panelsTable .panel-row');
    rows.forEach(row => {
        let name = row.cells[0]?.innerText.toLowerCase() || '';
        row.style.display = name.includes(search) ? '' : 'none';
    });
}

function exportKeys() {
    window.location.href = '?export=keys';
}

// Tambahan efek ripple pada tombol
document.querySelectorAll('button, .btn-sm').forEach(btn => {
    btn.addEventListener('click', function(e) {
        let ripple = document.createElement('span');
        ripple.style.position = 'absolute';
        ripple.style.borderRadius = '50%';
        ripple.style.transform = 'scale(0)';
        ripple.style.animation = 'ripple 0.6s linear';
        ripple.style.backgroundColor = 'rgba(255,255,255,0.3)';
        ripple.style.pointerEvents = 'none';
        let rect = this.getBoundingClientRect();
        let size = Math.max(rect.width, rect.height);
        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = (e.clientX - rect.left - size/2) + 'px';
        ripple.style.top = (e.clientY - rect.top - size/2) + 'px';
        this.style.position = 'relative';
        this.style.overflow = 'hidden';
        this.appendChild(ripple);
        setTimeout(() => ripple.remove(), 600);
    });
});

// Tambahan style untuk ripple animation
const style = document.createElement('style');
style.textContent = `
    @keyframes ripple {
        from { transform: scale(0); opacity: 1; }
        to { transform: scale(2); opacity: 0; }
    }
`;
document.head.appendChild(style);

// Export function
<?php if(isset($_GET['export'])): ?>
<?php
if($_GET['export'] == 'keys') {
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="keys_'.date('Y-m-d').'.json"');
    echo json_encode($keys, JSON_PRETTY_PRINT);
    exit;
}
?>
<?php endif; ?>
</script>

<!-- File untuk menampilkan halaman peringatan pada panel yang diblokir -->
<?php
// Buat file block_warning.php yang akan disertakan pada panel yang diblokir
$blockWarningContent = '<?php
$blockedFile = __DIR__ . "/../blocked_panels.json";
$currentPanel = basename(__DIR__);
$isBlocked = false;
$blockReason = "";
if(file_exists($blockedFile)) {
    $blocked = json_decode(file_get_contents($blockedFile), true);
    foreach($blocked as $b) {
        if($b["name"] === $currentPanel) {
            $isBlocked = true;
            $blockReason = $b["reason"];
            break;
        }
    }
}
if($isBlocked):
?>
<!DOCTYPE html>
<html>
<head>
    <title>⛔ PANEL DIBLOKIR ⛔</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            background: linear-gradient(135deg, #0a0a0a 0%, #1a0a2e 100%);
            font-family: "Orbitron", monospace;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
        }
        .block-container {
            text-align: center;
            padding: 50px;
            background: rgba(0,0,0,0.8);
            border-radius: 30px;
            border: 2px solid #e74a3b;
            box-shadow: 0 0 50px rgba(231,74,59,0.5);
            animation: pulse 2s infinite;
            max-width: 80%;
        }
        @keyframes pulse {
            0%, 100% { box-shadow: 0 0 20px rgba(231,74,59,0.3); }
            50% { box-shadow: 0 0 60px rgba(231,74,59,0.8); }
        }
        .block-icon {
            font-size: 100px;
            animation: shake 0.5s ease-in-out infinite;
            display: inline-block;
        }
        @keyframes shake {
            0%, 100% { transform: rotate(0deg); }
            25% { transform: rotate(10deg); }
            75% { transform: rotate(-10deg); }
        }
        h1 {
            font-size: 3em;
            margin: 20px 0;
            color: #e74a3b;
            text-shadow: 0 0 10px #e74a3b;
        }
        .reason {
            background: rgba(231,74,59,0.2);
            padding: 15px;
            border-radius: 10px;
            margin: 20px 0;
            border-left: 4px solid #e74a3b;
        }
        .glitch {
            animation: glitch 1s infinite;
        }
        @keyframes glitch {
            0%, 100% { transform: skew(0deg); }
            95% { transform: skew(0deg); }
            96% { transform: skew(5deg); }
            97% { transform: skew(-5deg); }
        }
        button {
            background: linear-gradient(135deg, #e74a3b, #c0392b);
            border: none;
            padding: 15px 30px;
            border-radius: 10px;
            color: white;
            font-family: "Orbitron", monospace;
            cursor: pointer;
            margin-top: 20px;
            transition: 0.3s;
        }
        button:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px #e74a3b;
        }
    </style>
</head>
<body>
    <div class="block-container">
        <div class="block-icon">⛔🚫⛔</div>
        <h1 class="glitch">PANEL DIBLOKIR !</h1>
        <p>Panel ini telah diblokir oleh Administrator.</p>
        <div class="reason">
            <i class="fas fa-exclamation-triangle"></i> <strong>ALASAN:</strong><br>
            <?= htmlspecialchars($blockReason) ?>
        </div>
        <p>⏰ Hubungi admin untuk informasi lebih lanjut.</p>
        <button onclick="history.back()"><i class="fas fa-arrow-left"></i> Kembali</button>
    </div>
</body>
</html>
<?php
    exit;
endif;
?>';

// Simpan file block_warning.php
if(!file_exists('block_warning.php')) {
    file_put_contents('block_warning.php', $blockWarningContent);
}
?>